class ExperienciaProfissional {
    constructor(id, empresa, cargo, descricao, dataAdmissao, dataDemissao) {
        this.id = id;
        this.empresa = empresa;
        this.cargo = cargo;
        this.descricao = descricao;
        this.dataAdmissao = dataAdmissao;
        this.dataDemissao = dataDemissao;
    }
}