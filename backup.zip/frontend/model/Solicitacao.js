class Solicitacao {
    constructor(departamento, cargo, tipoVaga, localVaga, qtdVagas, requisitos, motivo) {
        this.departamento = departamento;
        this.cargo = cargo;
        this.tipoVaga = tipoVaga;
        this.localVaga = localVaga;
        this.qtdVagas = qtdVagas;
        this.requisitos = requisitos;
        this.motivo = motivo;
    }
}
