class Candidato {

    constructor(nome, email, senha, cpf, celular, cep, rua, bairro, cidade, estado, pais, area, dataNascimento, genero) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.cpf = cpf;
        this.celular = celular;
        this.cep = cep;
        this.rua = rua;
        this.bairro = bairro;
        this.cidade = cidade;
        this.estado = estado;
        this.pais = pais;
        this.area = area;
        this.dataNascimento = dataNascimento;
        this.genero = genero;
    }
    
}
