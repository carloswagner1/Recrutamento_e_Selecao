class Inscricao {

    constructor(idCandidato, idProcesso) {
        this.idCandidato = idCandidato;
        this.idProcesso = idProcesso;
    }
}
