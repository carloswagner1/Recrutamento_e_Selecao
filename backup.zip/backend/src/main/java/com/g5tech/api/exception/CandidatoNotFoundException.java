package com.g5tech.api.exception;

public class CandidatoNotFoundException extends RuntimeException {
}
