package com.g5tech.api.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class InscricaoRequestDTO {
    private Long idCandidato;
    private Long idProcesso;
}
