package com.g5tech.api.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UsuarioRedefineSenhaDTO {
    private String email;
    private String tipo;
}
