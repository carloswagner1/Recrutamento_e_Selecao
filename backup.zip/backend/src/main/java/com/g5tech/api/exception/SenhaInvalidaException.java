package com.g5tech.api.exception;

public class SenhaInvalidaException extends RuntimeException {

}
