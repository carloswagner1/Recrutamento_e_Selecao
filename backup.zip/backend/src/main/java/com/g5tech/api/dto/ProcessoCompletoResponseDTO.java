package com.g5tech.api.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProcessoCompletoResponseDTO {
    private String cargo;
    private String descricaoCargo;
    private String requisitosDesejaveis;
}
