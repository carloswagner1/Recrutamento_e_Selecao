package com.g5tech.api.exception;

public class UsuarioNotFoundException extends RuntimeException {
}
