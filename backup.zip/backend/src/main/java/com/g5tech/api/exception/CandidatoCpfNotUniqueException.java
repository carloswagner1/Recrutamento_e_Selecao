package com.g5tech.api.exception;

public class CandidatoCpfNotUniqueException extends RuntimeException {
}
