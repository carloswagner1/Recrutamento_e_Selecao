package com.g5tech.api.exception;

public class CandidatoEmailNotUniqueException extends RuntimeException {
}
