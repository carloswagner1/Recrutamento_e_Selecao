package com.g5tech.api.exception;

public class FormacaoAcademicaNotFoundException extends RuntimeException {
}
