package com.g5tech.api.exception;

public class ExperienciaProfissionalNotFoundException extends RuntimeException {
}
