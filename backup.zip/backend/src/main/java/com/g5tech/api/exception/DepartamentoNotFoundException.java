package com.g5tech.api.exception;

public class DepartamentoNotFoundException extends RuntimeException {
}
