package com.g5tech.api.exception;

public class CargoNotFoundException extends RuntimeException {
}
