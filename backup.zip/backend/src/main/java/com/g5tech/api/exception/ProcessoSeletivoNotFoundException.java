package com.g5tech.api.exception;

public class ProcessoSeletivoNotFoundException extends RuntimeException {
}
