package com.g5tech.api.exception;

public class InscricaoNotFoundException extends RuntimeException {
}
